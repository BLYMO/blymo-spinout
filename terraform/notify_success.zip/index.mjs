exports.handler = async (event) => {
  console.log("Notifying Supabase of success for tenant:", event.tenant_id);
  const res = await fetch(`https://yfnnxtzkbylezkufppgm.supabase.co/functions/v1/on-provision-success`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tenant_id: event.tenant_id })
  });
  if (!res.ok) throw new Error("Supabase callback failed: " + await res.text());
  return { success: true };
};
