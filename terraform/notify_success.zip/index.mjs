import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

const sm = new SecretsManagerClient({ region: process.env.AWS_REGION });

export const handler = async (event) => {
  console.log("Notifying Supabase of success for tenant:", event.tenant_id);

  // Fetch the Supabase service role key at runtime from Secrets Manager
  const { SecretString } = await sm.send(
    new GetSecretValueCommand({ SecretId: process.env.SUPABASE_SERVICE_ROLE_KEY_ARN })
  );

  const res = await fetch(`https://yfnnxtzkbylezkufppgm.supabase.co/functions/v1/on-provision-success`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${SecretString}`
    },
    body: JSON.stringify({ tenant_id: event.tenant_id })
  });

  if (!res.ok) throw new Error("Supabase callback failed: " + await res.text());
  return { success: true };
};
